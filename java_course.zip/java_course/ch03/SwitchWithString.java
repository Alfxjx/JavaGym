class SwitchWithString 
{
	public static void main(String[] args) 
	{
		String a = "bb";
		switch(a){
			case "bb": 
				System.out.println("Hello World!");
		}
	}
}
