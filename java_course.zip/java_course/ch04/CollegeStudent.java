class CollegeStudent extends Student 
{
	public static void main(String[] args) 
	{
		System.out.println("Hello World!");
		int p = super.x;
	}
	int b= super.age;
	int c = super.x;
	int d = this.x;
}
