package pk;
class TestPkg 
{
	public static void main( String [] args){
		System.out.println( "Test Package Ok." );
	}
}
