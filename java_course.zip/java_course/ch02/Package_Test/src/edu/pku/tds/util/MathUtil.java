package edu.pku.tds.util;

public class MathUtil
{
	public static double add( double a, double b ){
		return a+b;
	}
}