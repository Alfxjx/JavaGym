package edu.pku.tds.ui;

public class ConsoleUI
{
	public static void show( String s ){
		System.out.println( s );
	}
};