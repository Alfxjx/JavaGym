import java.awt.*;
import java.applet.*;
import javax.swing.*;
public class HelloWorldApplet extends JApplet { 
	public void paint(Graphics g){
		g.drawString ("Hello World!",20,20);
	}
}
